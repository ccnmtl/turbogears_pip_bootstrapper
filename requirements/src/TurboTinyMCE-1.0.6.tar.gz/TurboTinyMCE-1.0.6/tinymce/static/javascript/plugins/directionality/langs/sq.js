// UK lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Drejtimi e majta ne te djathte',
directionality_rtl_desc : 'Drejtimi e djathta ne te majte'
});