// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
fullscreen_title : 'Affichage plein &eacute;cran',
fullscreen_desc : 'Affichage plein &eacute;cran/normal'
});