// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
autosave_unload_msg : 'Các thay đổi của bạn sẽ bị mất nếu bạn di chuyển khỏi trang này.'
});
