// RO lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Modific&#259;rile pe care le-ai f&#259;cut vor fi pierdute dac&#259; p&#259;r&#259;se&#351;ti aceast&#259; pagin&#259;.'
});
