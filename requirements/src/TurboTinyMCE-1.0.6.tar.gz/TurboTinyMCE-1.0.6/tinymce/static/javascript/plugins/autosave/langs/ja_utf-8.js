﻿// Japanese utf-8

tinyMCE.addToLang('',{
autosave_unload_msg : 'このページから離れれば、変更の部分がなくなる。'
});
