// IT lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Modalit&agrave; a schermo intero',
fullscreen_desc : 'Abilita o disabilita la modalit&agrave; a schermo intero'
});
