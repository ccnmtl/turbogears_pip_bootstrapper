// TR lang variables

tinyMCE.addToLang('flash',{
title : 'Flash ekle/d�zenle',
desc : 'Flash ekle/d�zenle',
file : 'Flash-Dosyas� (.swf)',
size : 'Boyut',
list : 'Flash Dosyalar�',
props : 'Flash �zellikleri',
general : 'Genel'
});
