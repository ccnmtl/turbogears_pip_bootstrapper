// EN lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Ndryshimet e bera do te humbasin po naviguat jashte kesaj faqeje.'
});