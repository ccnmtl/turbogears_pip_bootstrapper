tinyMCE

This is a TurboGears (http://www.turbogears.org) widget project.
You can view the widgets in the Toolbox.

Important Note:

This project cannot be released under the MIT license TurgoGears itself is released as.
The TinyMCE Javascript library itself is licensed under the LGPL license therefore this widgets
packake must be licensed uner LGPL too.
