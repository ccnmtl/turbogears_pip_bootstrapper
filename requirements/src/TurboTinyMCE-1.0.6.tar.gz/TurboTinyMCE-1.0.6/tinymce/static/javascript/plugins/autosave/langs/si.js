// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
autosave_unload_msg : 'Va&#353;e spremembe se bodo izgubile, &#269;e boste nalo&#382;ili drugo stran.'
});
