// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('',{
insert_advhr_desc : 'Wstaw/Edytuj poziom� lini�',
insert_advhr_width : 'Szeroko��',
insert_advhr_size : 'Wysoko��',
insert_advhr_noshade : 'Brak cienia'
});
