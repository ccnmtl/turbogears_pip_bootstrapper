# Release information about tinyMCE

version = "1.0.6"

description = "TinyMCE widget for TurboGears"
author = "Alberto Valverde Gonzalez"
email = "alberto@toscat.net"
copyright = "Alberto Valverde 2006"

url = "http://www.turbogears.org/svn/turbogears/widgets/TurboTinyMCE"
download_url = "http://www.turbogears.org/svn/turbogears/widgets/TurboTinyMCE"
license = "LGPL"
