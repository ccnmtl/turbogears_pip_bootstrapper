// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('flash',{
title : '插入/编辑 Flash电影',
desc : 'Flash电影描述',
file : 'Flash插件(.swf)',
size : '尺寸',
list : 'Flash插件列表',
props : 'Flash属性',
general : '一般'
});