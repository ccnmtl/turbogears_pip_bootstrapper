// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Cyffredinol',
tab_appearance : 'Ymddangosiad',
tab_advanced : 'Uwch',
general : 'Cyffredinol',
title : 'Teitl',
preview : 'Rhagolwg',
constrain_proportions : 'Cadw cymesuredd',
langdir : 'Cyfeiriad iaith',
langcode : 'C&ocirc;d iaith',
long_desc : 'Dolen disgrifiad hir',
style : 'Arddull',
classes : 'Dosbarthiadau',
ltr : 'Chwith i\'r dde',
rtl : 'Dde i\'r chwith',
id : 'Id',
image_map : 'Map delwedd',
swap_image : 'Cyfnewid delwedd',
alt_image : 'Delwedd amgen',
mouseover : 'llygoden drosodd',
mouseout : 'llygoden allan',
misc : 'Arall',
example_img : 'Delwedd&nbsp;rhagolwg&nbsp;delwedd',
missing_alt : 'Wyt ti\'n sicr eisiau parhau heb gynnwys Disgrifiad Delwedd? Heb un, mae\'n bosib na fydd y ddelwedd yn hygyrch i ddefnyddwyr gydag anableddau, neu rhai gyda phorwr testun, neu sy\'n pori gyda delweddau wedi\'u diffodd.'
});
