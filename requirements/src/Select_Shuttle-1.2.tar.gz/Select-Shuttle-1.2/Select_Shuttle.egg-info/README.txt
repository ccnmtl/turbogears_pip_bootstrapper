Select-Shuttle

This is a TurboGears (http://www.turbogears.org) widget project.
You can view the widgets in the Toolbox.

This widget shows two Select boxes and four buttons to move items
between them.  Their ids and descriptions are moved from one side
to the other either with a button press or a double click.

As an alternative, a hyperlink, an image and some custom text may
be added below the option boxes to allow taking some action (the
suggested action is add new options).  A target for the destination
may also be specified.
