// IT lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Riga orizzontale',
insert_advhr_width : 'Larghezza',
insert_advhr_size : 'Altezza',
insert_advhr_noshade : 'Senza rilievo'
});
