// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('',{
insert_advhr_desc : '插入/编辑 水平标尺',
insert_advhr_width : '宽度',
insert_advhr_size : '高度',
insert_advhr_noshade : '无阴影'
});
