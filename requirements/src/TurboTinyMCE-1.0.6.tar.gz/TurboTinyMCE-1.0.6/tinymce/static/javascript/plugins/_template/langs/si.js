// SI lang variables ISO-8859-2

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'To je samo primer popup okna',
template_desc : 'To je samo primer gumba'
});
