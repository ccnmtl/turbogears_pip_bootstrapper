/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.4 2005/10/18 13:59:42 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
insert_emotions_title : 'Vložit emotikonu',
emotions_desc : 'Emotikony'
});

