﻿// 日本語 unicode utf-8

tinyMCE.addToLang('advimage',{
tab_general : '一般',
tab_appearance : '表示',
tab_advanced : '詳細',
general : '一般',
title : 'タイトル',
preview : 'プレビュー',
constrain_proportions : '縦横比を固定',
langdir : '言葉の向き',
langcode : '言葉コード',
long_desc : '長い説明のリンク',
style : 'スタイル',
classes : 'クラス',
ltr : '左から右へ',
rtl : '右から左へ',
id : 'Id',
image_map : 'イメージマップ',
swap_image : 'スワップイメージ',
alt_image : '代わりのイメージ',
mouseover : 'マウス上',
mouseout : 'マウス外',
misc : 'その他',
example_img : '見かけ&nbsp;プレビュー&nbsp;イメージ',
missing_alt : '代替テキストを入力しませんでした。 なくてもいいですか。'
});
