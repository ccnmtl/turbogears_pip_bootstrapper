// IT lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direzione da sinistra a destra',
directionality_rtl_desc : 'Direzione da destra a sinistra'
});
