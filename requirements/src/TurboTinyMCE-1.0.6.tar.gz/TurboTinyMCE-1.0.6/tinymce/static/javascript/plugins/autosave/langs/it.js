// IT lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'I cambiamenti andranno persi se si carica un\'altra pagina.'
});
