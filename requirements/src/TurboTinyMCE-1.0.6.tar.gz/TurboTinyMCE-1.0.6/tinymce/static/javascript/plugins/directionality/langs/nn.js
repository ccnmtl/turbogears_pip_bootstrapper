// nn = Norwegian (nynorsk) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Venstre mot h&oslash;gre',
directionality_rtl_desc : 'H&oslash;gre mot venstre'
});
