// RO lang variables

tinyMCE.addToLang('emotions',{
title : 'Insereaz&#259; figurin&#259;',
desc : 'Figurine',
cool : 'Mi&#351;to',
cry : 'Pl&#226;nset',
embarassed : 'Ru&#351;inat',
foot_in_mouth : 'Picior &#238;n gur&#259;!',
frown : '&#206;ncruntat',
innocent : 'Inocent',
kiss : 'Pupic',
laughing : 'R&#226;sete',
money_mouth : 'Gur&#259; bogat&#259;',
sealed : 'Sigilat',
smile : 'Z&#226;mbet',
surprised : 'Surprins',
tongue_out : 'Cu limbu&#355;a pe-afar&#259;',
undecided : 'Nedecis',
wink : 'Trage cu ochiul',
yell : 'Url&#259;'
});
