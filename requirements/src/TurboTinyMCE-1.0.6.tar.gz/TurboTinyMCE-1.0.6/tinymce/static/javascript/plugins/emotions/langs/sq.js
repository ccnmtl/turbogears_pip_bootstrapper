// UK lang variables

tinyMCE.addToLang('emotions',{
title : 'Nderfut emocione',
desc : 'Emocione',
cool : 'Njesh',
cry : 'Qaj',
embarassed : 'Ne siklet',
foot_in_mouth : 'Kemben ne goje',
frown : 'Hmm...',
innocent : 'I pafajshem',
kiss : 'Puthje',
laughing : 'Qeshje',
money_mouth : 'Goje me para',
sealed : 'I vulosur',
smile : 'Buzeqeshje',
surprised : 'I �uditur',
tongue_out : 'Perqeshje',
undecided : 'I pavendosur',
wink : 'Hmm...',
yell : 'Bertitje'
});