// RO lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Acesta este doar model de tip popup',
template_desc : 'Acesta este doar un model de buton'
});
