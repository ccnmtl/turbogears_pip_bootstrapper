// RO lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Afi&#351;are pe tot ecranul',
fullscreen_desc : 'Comut&#259; modul de afi&#351;are'
});
