﻿// Japanese utf-8 variables

tinyMCE.addToLang('',{
fullscreen_title : '全画面表示',
fullscreen_desc : '全画面表示をトグル'
});
