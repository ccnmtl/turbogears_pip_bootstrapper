// HU lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Elhelyezked�s balr�l jobbra',
directionality_rtl_desc : 'Elhelyezked�s jobbr�l balra'
});
