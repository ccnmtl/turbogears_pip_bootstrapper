// IT lang variables

tinyMCE.addToLang('flash',{
title : 'Inserisci o modifica oggetto Flash',
desc : 'Inserisci o modifica oggetto Flash',
file : 'File Flash (.swf)',
size : 'Dimensioni',
list : 'Lista file',
props : 'Propriet&agrave;',
general : 'Generale'
});
