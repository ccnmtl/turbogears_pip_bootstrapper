// 日本語 utf-8 lang variables

tinyMCE.addToLang('emotions',{
title : '顔キャラを挿入',
desc : '顔キャラ',
cool : 'カッコイイ',
cry : '泣く',
embarassed : '照れる',
foot_in_mouth : '口にチャック',
frown : 'ボーッ',
innocent : '天使',
kiss : 'キス',
laughing : '笑う',
money_mouth : 'お金',
sealed : '',
smile : '笑顔',
surprised : 'ビックリ',
tongue_out : 'ペロッ',
undecided : 'ふ～ん',
wink : 'ウィンク',
yell : '叫ぶ'
});
