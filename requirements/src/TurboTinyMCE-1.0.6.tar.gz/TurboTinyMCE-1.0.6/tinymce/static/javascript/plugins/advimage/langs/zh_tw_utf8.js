// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com


tinyMCE.addToLang('advimage',{
tab_general : '一般',
tab_appearance : '外觀',
tab_advanced : '進階',
general : '一般',
title : '標題',
preview : '預覽',
constrain_proportions : '比例限制',
langdir : '語言用法',
langcode : '語碼',
long_desc : '完整說明連結',
style : '式樣',
classes : '分類',
ltr : '由左至右',
rtl : '由右至左',
id : '編號',
image_map : '圖檔映射',
swap_image : '圖檔交換',
alt_image : '替代圖檔',
mouseover : '當滑鼠移入',
mouseout : '當滑鼠移出',
misc : '雜項',
example_img : '外觀&nbsp;預覽&nbsp;圖檔',
missing_alt : '確定要在不含圖檔說明的狀況下繼續執行嗎？\n沒有圖檔說明可能會導致那些像是以純文字瀏覽器或\n關閉瀏覽器圖檔顯現功能的用戶無法順利讀取資訊。'
});
