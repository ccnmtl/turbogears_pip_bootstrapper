This is a Python implementation of John Gruber's Markdown.  Please see
http://www.freewisdom.org/projects/python-markdown for more
information, including installation and usage.

Distributed under GPL and BSD licenses.
