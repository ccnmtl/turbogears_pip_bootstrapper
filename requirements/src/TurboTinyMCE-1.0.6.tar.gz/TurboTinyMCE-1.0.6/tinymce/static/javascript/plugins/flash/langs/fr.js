// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('flash',{
title : 'Gestionnaire d\'animation Flash',
desc : 'Ins&eacute;rer une animation Flash',
file : 'Fichier Flash (.swf)',
size : 'Taille',
list : 'Fichiers Flash',
props : 'Propri&eacute;t&eacute;s Flash',
general : 'G&eacute;n&eacute;ral'
});
