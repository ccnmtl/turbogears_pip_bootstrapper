// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('',{
fullscreen_title : 'Fuldsk&aelig;rmstilstand',
fullscreen_desc : 'Sl� fuldsk&aelig;rmstilstand til/fra'
});
