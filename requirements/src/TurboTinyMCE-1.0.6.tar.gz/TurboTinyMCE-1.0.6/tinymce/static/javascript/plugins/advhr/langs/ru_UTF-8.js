// RU UTF-8 lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Вставить / редактировать горизонтальный разделитель',
insert_advhr_width : 'Ширина',
insert_advhr_size : 'Высота',
insert_advhr_noshade : 'Без тени'
});
