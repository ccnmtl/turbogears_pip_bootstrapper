// UK lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Kjo eshte nje dritare teme',
template_desc : 'Ky eshte nje buton teme'
});