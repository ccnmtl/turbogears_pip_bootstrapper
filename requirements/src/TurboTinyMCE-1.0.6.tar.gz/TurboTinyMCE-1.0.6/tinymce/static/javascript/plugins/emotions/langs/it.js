// IT lang variables

tinyMCE.addToLang('emotions',{
title : 'Inserisci emoticon',
desc : 'Emoticons',
cool : 'Fico',
cry : 'Pianto',
embarassed : 'Imbarazzo',
foot_in_mouth : 'Calcio in faccia',
frown : 'Tristezza',
innocent : 'Innocenza',
kiss : 'Bacio',
laughing : 'Risata',
money_mouth : 'Soldi',
sealed : 'Bocca chiusa',
smile : 'Sorriso',
surprised : 'Sorpresa',
tongue_out : 'Linguaccia',
undecided : 'Indecisione',
wink : 'Occhiolino',
yell : 'Urlo'
});
