// nb = Norwegian (bokm&aring;l) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
insert_advhr_desc : 'Lage/Redigere horisontal linje',
insert_advhr_width : 'Bredde',
insert_advhr_size : 'H&oslash;yde',
insert_advhr_noshade : 'Ingen skygge'
});
