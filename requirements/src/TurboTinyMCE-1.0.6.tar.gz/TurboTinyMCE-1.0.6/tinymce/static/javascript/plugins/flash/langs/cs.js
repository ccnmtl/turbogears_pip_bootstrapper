/**
 * Czech lang variables
 * encoding: utf-8
 *
 * $Id: cs.js,v 1.8 2006/02/23 09:05:57 spocke Exp $
 */

tinyMCE.addToLang('flash',{
title : 'Vložit / editovat Flash',
desc : 'Vložit / editovat Flash',
file : 'Flash soubor (.swf)',
size : 'Velikost',
list : 'Flash soubory',
props : 'Flash nastavení',
general : 'Obecné'
});
