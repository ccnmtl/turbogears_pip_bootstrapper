from turbokid import kidsupport

KidSupport = kidsupport.KidSupport

__all__ = ["KidSupport"]