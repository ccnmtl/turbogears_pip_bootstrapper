// NL lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Volledig scherm',
fullscreen_desc : 'Volledig scherm aan/uit'
});
